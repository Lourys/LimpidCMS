<?php

class Example_Actions
{
    public function __construct()
    {
        $this->CI =& CMS_Controller::$instance;
    }

    public function onInstall()
    {
        $this->CI->load->dbforge();

        // Fields initialization
        $fields = array(
            'ip_address' => array(
                'type' => 'VARCHAR',
                'constraint' => '15'
            ),
            'first_visit' => array(
                'type' =>'TIMESTAMP'
            ),
            'last_visit' => array(
                'type' => 'TIMESTAMP',
                'null' => true,
            ),
        );
        $this->CI->dbforge->add_key('ip_address', TRUE);
        $this->CI->dbforge->add_field($fields);

        // Create table
        return $this->CI->dbforge->create_table('web_stats', true);
    }

    public function onEnable()
    {
        return true;
    }

    public function onDisable()
    {
        return true;
    }

    public function onUninstall()
    {
        $this->CI->load->dbforge();

        // Drop table
        return $this->CI->dbforge->drop_table('web_stats',TRUE);
    }

    public function onUpdate()
    {
        return true;
    }
}