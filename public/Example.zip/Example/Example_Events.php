<?php
/**
 * Created by PhpStorm.
 * User: lucas
 * Date: 8/29/2017
 * Time: 10:48 PM
 */

class Example_Events
{
    public function __construct()
    {
        $this->CI =& CMS_Controller::$instance;
        $this->CI->load->add_module('Example');
        $this->CI->load->library('Example_Manager', null, 'exampleManager');
        $this->CI->emitter->on('limpid.initialization', [$this, 'logUser']);
    }

    public function logUser()
    {
        if (!$this->CI->exampleManager->getEntry($_SERVER['REMOTE_ADDR']))
            $this->CI->exampleManager->logUser($_SERVER['REMOTE_ADDR']);
        else
            $this->CI->exampleManager->editEntry($_SERVER['REMOTE_ADDR'], ['last_visit' => date('Y-m-d H:i:s')]);
    }
}